//
// Created by agbek on 02/12/2023.
//

#include "equipements.h"

equipement::equipement(int solidite, bool etat,int x ,int y): d_solidite{solidite},
d_detruit{etat}, d_position_equipement(x,y){}

int equipement::getSolidite() const {
    return d_solidite;
}

void equipement::setEstDetruit(bool etat) {
    d_detruit=etat;
}

bool equipement::estDetruit() const {
    return d_detruit;
}

void equipement::setSolidite(int solidite) {
    d_solidite=solidite;
}
