//
// Created by dell on 20/12/2023.
//

#ifndef APP_AVENTURIER_JEU_PERSONNAGES_H
#define APP_AVENTURIER_JEU_PERSONNAGES_H

#include "position.h"

class personnage {
public:
    virtual ~personnage() = default;
    personnage(int x,int y,char c);
    //virtual void attaque()= 0; //qu'est ce qu'elle va prendre comme paramètre ????
    //donc attaque n'est pas une méthode commune car même si le nom est commun
    //le reste ne l'est pas signature + contenu
    //elle prend monstre ou aventurier comme paramètre ?????
    //ah ouais ce n'est pas possible car on a pas les même param pour l'aventurier et pour les monstres
    //that is wild
    void setVie(int pointVie);
    void setForce(int pointForce);
    int pointVie() const;
    int pointForce() const;
    int posX() const;
    int posY() const;
    void setPosX(int x);
    void setPosY(int y);
    char caracter() const;

    //virtual void estAttaque()=0;//aussi ça attaque de l'adverssaire va appeler ça ????
    virtual void seDeplace(int input)=0; //je ne sais pas non plus si elle va prendre des paramètres, let's see
    virtual void attaquer(personnage &personnage1)=0;
    virtual void estAttaque(int pointForce)=0;
private:
    int d_pointVie=100;
    int d_pointForce=100;
    position d_position_personnage;
};


#endif //APP_AVENTURIER_JEU_PERSONNAGES_H
