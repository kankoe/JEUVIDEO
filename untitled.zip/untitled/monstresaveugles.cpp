//
// Created by dell on 15/12/2023.
//

#include "monstresaveugles.h"

void monstresaveugles::seDeplace(int input) {

}
