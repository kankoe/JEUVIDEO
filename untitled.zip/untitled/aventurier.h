//
// Created by agbek on 19/12/2023.
//

#ifndef APP_AVENTURIER_JEU_AVENTURIERS_H
#define APP_AVENTURIER_JEU_AVENTURIERS_H

#include "personnage.h"
#include "equipements.h"
#include "armures.h"
#include "epees.h"
#include <vector>
#include <memory>
/*
 * la class aventurier représente je joueur principal du jeu video il hérite de personnage
 * */
class aventurier : public personnage{

public:
    aventurier(int x, int y,char c);//peut être ajouter un constructeur avec
    //des equipements à la construction ??? franchement jsp let's see
    //void affiche() const override;//comment va se faire l'affichage hummm, pour l'instant on appelle la classe afficheur ?
    void attaquer(personnage &monstreAttaquer) override;
    void estAttaque(int pointForce) override;
    void seDeplace(int input) override;
private:
    // Un aventurier a des equipement de defences et des equipements d'attaque
    armure *d_armure;
    epee *d_epee;
    static constexpr int ARMUR_TAUX_DE_PERTE = 3/4;
    static constexpr int EPEE_TAUX_DE_PERTE = 1;
    static constexpr int VIE_TAUX_DE_PERTE = 1/4;
};


#endif //APP_AVENTURIER_JEU_AVENTURIERS_H



