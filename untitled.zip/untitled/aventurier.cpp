//
// Created by agbek on 19/12/2023.
//

#include "aventurier.h"


aventurier::aventurier(int x, int y,char c): personnage{x,y,c}
{}


void aventurier::seDeplace(int input) {
    switch(input)
    {
        //move up
        case 'z':
            setPosX(posX()-1);
            break;
            //move down
        case 's':
            setPosX(posX()+1);
            break;
            //move left
        case 'q':
            setPosY(posY()-1);
            break;
            //move right
        case 'd':
            setPosY(posY()+1);
            break;
        default:
            break;
    }
}


void aventurier::attaquer(personnage &monstreAttaquer) {
    int probabilite = rand()%100;
    //calcule de l'attaque
    int attaque = (*this).pointForce()+d_epee->getSolidite();
    if (probabilite<80){
        attaque *= 0.9;
    }
    monstreAttaquer.estAttaque(attaque);
    d_epee->utiliser(EPEE_TAUX_DE_PERTE);
}

void aventurier::estAttaque(int pointForce) {
    if ((*this).pointVie() > 0) {
        if ( d_armure->estDetruit() != true) {
            d_armure->utiliser(pointForce*ARMUR_TAUX_DE_PERTE);
            (*this).setVie(pointVie()-pointForce * VIE_TAUX_DE_PERTE);
        }else{
            (*this).setVie(pointVie()-pointForce);
        }
    }
    else{
        //kill();
    }
}