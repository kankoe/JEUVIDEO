//
// Created by agbek on 02/12/2023.
//

#ifndef APP_AVENTURIER_JEU_ATTAQUES_H
#define APP_AVENTURIER_JEU_ATTAQUES_H

/*
 * dans une optique d'evolutivité,un personnage du jeu pourrai avoir différente type d'attaque
 * */
class attaques {

};


#endif //APP_AVENTURIER_JEU_ATTAQUES_H
