#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"
//
// Created by agbek on 09/01/2024.
//
