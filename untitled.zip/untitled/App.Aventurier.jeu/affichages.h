//
// Created by agbek on 02/12/2023.
//

#ifndef APP_AVENTURIER_JEU_AFFICHAGES_H
#define APP_AVENTURIER_JEU_AFFICHAGES_H
/*
 * afficher le jeu de differentes maniere et de l imprimer.
 * */

class affichages {

};


#endif //APP_AVENTURIER_JEU_AFFICHAGES_H
